# Movie-Rating
   Import the given sql files(tables) under the database name moviereviews.
