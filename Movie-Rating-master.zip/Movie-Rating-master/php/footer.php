<script src='https://kit.fontawesome.com/a076d05399.js'></script>
<style>
i{
    font-size:40px;
}
#fb:hover {
  color: royalblue;
  transform: rotateZ(360deg);
}

#yt:hover {
  color: red;
  transform: rotateZ(360deg);
}

#insta:hover {
  color: rgb(230, 41, 119);
  transform: rotateZ(360deg);
}
#twit:hover {
  color: darkturquoise;
  transform: rotateZ(360deg);
}
td{
  padding-left: 10px;
}
.fas:hover{
color:rgb(240, 99, 17);
}
#social{
  background-image: linear-gradient(to right,rgb(202, 65, 118),rgb(65, 147, 202));
  font-size:32px;
}
#social i{
  font-size:36px;margin-inline-start: 10px;
}
#contact{
  background-image: linear-gradient(to right,rgb(65, 147, 202),rgb(202, 65, 118));
  
  
}
#contact i{
  font-size: 25px;margin-top:10px; margin-right:5px;
}
#contact a{
    color:white;
}


#site_footer{
  background-image: linear-gradient(to right,rgb(202, 65, 118),rgb(65, 147, 202));
}
#site_footer a{
  font-size:24px; margin-bottom: 10px;
}
footer{
  font-family: sans-serif;
}
</style>
<footer>
  <table width="100%" style="background-color:rgb(58, 51, 51) ">
    <tr>
      <td rowspan="3" > <a href="select.php">
          <img src="../images/logo.jpg" height="70px" width="170px">
          </a><br>
         </td>
      <td rowspan="3" id="social">  <h2 style="color:white;">Follow us on:  <br><br>
    <a href="#"><i class='fab fa-facebook-square' id="fb"></i> </a>
    <a href="#"><i class='fab fa-twitter-square' id="twit"></i></a>
    <a href="#"><i class='fab fa-instagram'  id="insta"></i></a>
    <a href="#"><i class='fab fa-youtube-square'  id="yt"></i></a>
    
    
    
      </h2></td>
      <td rowspan="3" id="contact">
        <p style="font-size: 24px; color:white;">Contact Us: <br>
          <i class="fas fa-address-book " >  <a href="tel:+91 7582029194">+91 7582029194 </a></i><br>
            <i class="fas fa-envelope " > <a href="mailto:info@movieRating.com">info@movieRating.com</a></i></p>
      </td>
      <td rowspan="3" id="site_footer">
        <a href="#"> FAQ </a> <br>
        <a href="#"> Site Map</a><br>
        <a href="#"> Terms and Conditions</a><br>

      </td>

      
    </tr>
  </table>
  
</footer>